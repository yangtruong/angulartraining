import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Account, AccountService } from '../account.service';

@Component({
  selector: 'app-list-accounts',
  templateUrl: './list-accounts.component.html',
  styleUrls: ['./list-accounts.component.css']
})
export class ListAccountsComponent {

  message: string;
  accounts: Account[];
  error=null;
  constructor(private myservice: AccountService, private router: Router) {
    this.myservice.getAccounts().subscribe(
      response => this.handleSuccessfulResponse(response)
      ,
      error=>{this.error=error.message}
    );
  }
  handleSuccessfulResponse(response) {
    console.log(response)
    this.accounts = response;
  
  }

}
