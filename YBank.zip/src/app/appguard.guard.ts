import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AccountService } from './account.service';

@Injectable({
  providedIn: 'root'
})

export class AppguardGuard implements CanActivate {

  
  constructor(public service:AccountService){
    
  }

  canActivate(){
    return this.service.isAuthenticated();
    
  }
  
}
