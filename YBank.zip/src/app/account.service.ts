import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class AccountService {

  
  http:HttpClient;
  
  constructor(public httpClient:HttpClient) { 
    
    this.http = httpClient;
    this.getAccounts(); 
  }

  public getAccounts() {
    console.log("in service get accounts");
      return this.httpClient.get<Account>("http://localhost:3000/accounts");
  }
  public addAccount(account: Account) {
    console.log("ins service add");
    console.log(account);
    return this.httpClient.post("http://localhost:3000/accounts", account);
  }

  public isAuthenticated():boolean{
    let auth = localStorage.getItem('authenticated');
    if(auth!=null) {
      return true;
    }
    return false;
  }

}  

export class Account {

  id:string;
  accountName:string;
  balance:number;
  
}


