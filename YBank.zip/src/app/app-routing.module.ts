import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddAccountComponent } from './add-account/add-account.component';
import { AppguardGuard } from './appguard.guard';
import { DepositComponent } from './deposit/deposit.component';
import { ListAccountsComponent } from './list-accounts/list-accounts.component';
import { LoginComponent } from './login/login.component';
import { TransferComponent } from './transfer/transfer.component';
import { WithdrawComponent } from './withdraw/withdraw.component';

const routes: Routes = [
  
  { path: "", component: LoginComponent },
  { path: "login", component: LoginComponent },
  { path: "list", component: ListAccountsComponent, canActivate:[AppguardGuard] },
  { path: "deposit", component: DepositComponent },
  { path: "withdraw", component: WithdrawComponent },
  { path: "transfer", component: TransferComponent },
  { path: "add", component: AddAccountComponent, canActivate:[AppguardGuard] }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
