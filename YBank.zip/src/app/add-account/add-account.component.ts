import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Account, AccountService } from '../account.service';

@Component({
  selector: 'app-add-account',
  templateUrl: './add-account.component.html',
  styleUrls: ['./add-account.component.css']
})
export class AddAccountComponent {
  constructor(private myservice: AccountService,private router: Router) { }//dependency injection


  onSubmit(account:Account):any{
    console.log(account);
     this.myservice.addAccount(account).subscribe(data => {
      alert("account added successfully"+data);
      this.router.navigate(['/list']);
    });
  }
}
