import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  
  onSubmit(loginForm: NgForm) {

    if(loginForm.value.username=='super' && loginForm.value.password=='secret'){
      alert('login success')
      localStorage.setItem('authenticated','yes');
    }
    else {
        alert('login failed')
    }
    
  }
  
}
